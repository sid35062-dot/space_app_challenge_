import { baseline, evaluate } from './health.js';

const storageKey = 'orbit-health-v1';
const main = document.querySelector('#main');
const escape = value => String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
const dateLabel = value => new Date(value).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
function sampleState() {
  const rates = [61, 64, 62, 65, 63, 66, 64, 68, 65, 69, 67, 73, 75, 76];
  return { readings: rates.map((heartRate, index) => {
    const date = new Date();
    date.setDate(date.getDate() - 13 + index);
    date.setHours(8, 0, 0, 0);
    return { id: `sample-${index}`, date: date.toISOString(), heartRate, sleep: index > 10 ? 5.8 : 7.5, fatigue: index > 10 ? 7 : 3, mood: 'Steady', exercise: true, symptoms: '', source: 'Simulated sensor', sample: true };
  }), actions: [], checkins: [] };
}
let state;
let storageAvailable = true;
try {
  const saved = JSON.parse(localStorage.getItem(storageKey) || 'null');
  state = saved && Array.isArray(saved.readings) && Array.isArray(saved.actions) && Array.isArray(saved.checkins) ? saved : sampleState();
} catch { state = sampleState(); }
let range = 14;
function toast(message) {
  const box = document.querySelector('#toast');
  box.textContent = message;
  box.style.display = 'block';
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => { box.style.display = 'none'; }, 4500);
}
function save() {
  try { localStorage.setItem(storageKey, JSON.stringify(state)); storageAvailable = true; return true; }
  catch { storageAvailable = false; toast('Device storage is unavailable. Export your summary to keep this session.'); return false; }
}
function heading(title, subtitle, action = '') {
  return `<div class="page-heading"><div><div class="eyebrow">ARES EXPEDITION / CREW HEALTH</div><h1>${title}</h1><p>${subtitle}</p></div>${action}</div>`;
}
function sparkline(values, color = '#b4e9d3') {
  const min = Math.min(...values) - 2;
  const max = Math.max(...values) + 2;
  const points = values.map((value, index) => `${index * 200 / Math.max(values.length - 1, 1)},${30 - (value - min) / (max - min) * 28}`).join(' ');
  return `<svg class="sparkline" viewBox="0 0 200 34" preserveAspectRatio="none" aria-hidden="true"><polyline points="${points}" fill="none" stroke="${color}" stroke-width="1.7" vector-effect="non-scaling-stroke"/></svg>`;
}
function chart(key = 'heartRate', title = 'Resting heart rate', unit = 'bpm') {
  const readings = state.readings.slice(-range);
  const values = readings.map(item => item[key]);
  const base = baseline[key];
  const min = Math.floor(Math.min(...values, base) - 3);
  const max = Math.ceil(Math.max(...values, base) + 3);
  const y = value => 150 - (value - min) / (max - min) * 125;
  const x = index => 40 + index * 500 / Math.max(values.length - 1, 1);
  const points = values.map((value, index) => `${x(index)},${y(value)}`).join(' ');
  const grid = [min, Math.round((min + max) / 2), max].map(value => `<line x1="40" x2="540" y1="${y(value)}" y2="${y(value)}" stroke="#2b3941"/><text x="3" y="${y(value) + 4}">${value}</text>`).join('');
  return `<div class="card"><div class="card-head"><h2>${title}</h2><div class="range-buttons">${[7, 14].map(days => `<button data-range="${days}" class="${range === days ? 'selected' : ''}" aria-pressed="${range === days}">${days} readings</button>`).join('')}</div></div><p>Compared with your sample baseline · ${unit}</p><div class="chart"><svg viewBox="0 0 560 190" role="img" aria-label="${title}, latest ${values.at(-1)} ${unit}, sample baseline ${base} ${unit}">${grid}<line x1="40" x2="540" y1="${y(base)}" y2="${y(base)}" stroke="#78978b" stroke-dasharray="5 5"/><polygon points="40,150 ${points} 540,150" fill="#b4e9d3" opacity=".045"/><polyline points="${points}" fill="none" stroke="#b4e9d3" stroke-width="2.5"/><circle cx="${x(values.length - 1)}" cy="${y(values.at(-1))}" r="4" fill="#b4e9d3"/>${[0, Math.floor((values.length - 1) / 2), values.length - 1].map(index => `<text x="${x(index)}" y="180" text-anchor="middle">${dateLabel(readings[index].date)}</text>`).join('')}</svg></div><div class="legend"><span><i></i> Recorded readings</span><span><i class="dashed"></i> Sample baseline ${base} ${unit}</span></div></div>`;
}
function overview() {
  const latest = state.readings.at(-1);
  const alerts = evaluate(state.readings);
  const metrics = [
    ['Resting heart rate', latest.heartRate, 'bpm', `${latest.heartRate - baseline.heartRate >= 0 ? '+' : ''}${latest.heartRate - baseline.heartRate} bpm from baseline`, 'heartRate', latest.heartRate >= baseline.heartRate + 10],
    ['Sleep duration', latest.sleep, 'hrs', `Target baseline ${baseline.sleep} hours`, 'sleep', latest.sleep < 6],
    ['Fatigue level', latest.fatigue, '/ 10', 'Daily self-assessment', 'fatigue', latest.fatigue >= 7],
    ['Exercise', latest.exercise ? 'Complete' : 'Pending', '', 'Latest check-in status', null, false]
  ];
  return heading('Your health, in view.', `Welcome back, Alex. Here’s your latest crew health overview.`, '<a class="button primary" href="#checkin">＋ Daily check-in</a>') +
    `<div class="status-banner"><span class="status-symbol">${alerts.length ? '!' : '✓'}</span><div><h2>${alerts.length ? `${alerts.length} areas need your attention` : 'No active demo rule alerts'}</h2><p>${alerts.length ? 'Review recent changes and complete your follow-up actions.' : 'Continue recording your daily measurements and check-ins.'}</p></div><a href="#alerts">Review health status ↗</a></div><div class="metrics">${metrics.map(([label, value, unit, note, key, warning]) => `<section class="card"><div class="metric-label">${label}<span>${warning ? '↗' : '·'}</span></div><div class="metric-value" style="${key ? '' : 'font-size:26px;min-height:41px;padding-top:6px'}">${value}<small>${unit}</small></div><div class="metric-note ${warning ? 'warning' : ''}">${note}</div>${key ? sparkline(state.readings.slice(-14).map(item => item[key]), warning ? '#efbf79' : '#b4e9d3') : '<p class="notice">Exercise adherence log</p>'}</section>`).join('')}</div><div class="columns">${chart()}<section class="card"><div class="card-head"><h2>Attention & follow-up</h2><span class="chip amber">${alerts.length} ACTIVE</span></div>${alerts.map(alert => `<div class="alert-preview"><h3>${alert.title}</h3><p>${alert.evidence}</p><a class="text-link" href="#alerts">Review next steps →</a></div>`).join('') || '<p>No active alerts from the illustrative rules.</p>'}</section></div><div class="columns lower"><section class="card"><div class="card-head"><h2>Recent activity</h2><a class="text-link" href="#summary">View records ↗</a></div>${state.checkins.slice(-2).reverse().map(item => `<div class="activity"><span>✓</span><div><strong>Daily check-in recorded</strong><small>${escape(item.mood)} · Fatigue ${item.fatigue}/10</small></div><time>${dateLabel(item.date)}</time></div>`).join('')}<div class="activity"><span>⌁</span><div><strong>Latest measurement available</strong><small>${escape(latest.source)} · ${new Date(latest.date).toLocaleString()}</small></div></div><div class="activity"><span>◎</span><div><strong>Personal baseline loaded</strong><small>Illustrative pre-mission profile</small></div><time>DEMO</time></div></section><section class="card checkin-card"><span class="eyebrow">A MOMENT FOR YOURSELF</span><h2>How are you feeling today?</h2><p>Your daily check-in adds context to the numbers. Record sleep, symptoms, mood, and activity.</p><a class="button" href="#checkin">Start daily check-in →</a></section></div><p class="notice">Latest measurement ${new Date(latest.date).toLocaleString()} · ${latest.sample ? 'Simulated data' : 'Manual entry'} · ${Date.now() - new Date(latest.date).getTime() > 86400000 ? 'Over 24 hours old. Add a current reading.' : 'Recorded within 24 hours.'}</p>`;
}
function checkin() {
  return heading('Daily check-in', 'Take a moment to record your measurements and how you feel.') + `<section class="card"><form id="checkin-form"><div class="card-head"><h2>Today’s health record</h2><span class="chip">MANUAL ENTRY</span></div><div class="form-grid"><label>Resting heart rate (bpm)<input name="heartRate" type="number" min="20" max="250" required></label><label>Sleep duration (hours)<input name="sleep" type="number" min="0" max="24" step="0.1" required></label><label>Fatigue (0 = none, 10 = extreme)<input name="fatigue" type="number" min="0" max="10" required></label><label>Mood<select name="mood"><option>Steady</option><option>Positive</option><option>Low</option><option>Anxious</option><option>Irritable</option></select></label><label>Planned exercise<select name="exercise"><option value="true">Completed</option><option value="false">Pending / missed</option></select></label><label>Stress (0 = none, 10 = extreme)<input name="stress" type="number" min="0" max="10" required></label><label class="full">Symptoms or context (optional)<textarea name="symptoms" maxlength="2000" placeholder="Record symptoms, workload changes, or sleep interruptions"></textarea></label></div><div class="form-actions"><button class="button primary" type="submit">Save check-in</button><p>Entries are stored in this browser on this device.</p></div></form></section>`;
}
function alertsView() {
  const alerts = evaluate(state.readings);
  return heading('Alerts & actions', 'Review the evidence, record your response, and plan a reassessment.') + `<p class="notice">These illustrative rules and checklists need clinical validation before operational use. Baseline values are sample values.</p>` + alerts.map(alert => {
    const history = state.actions.filter(action => action.alertId === alert.id);
    return `<section class="card alert-card"><div class="card-head"><h2>${alert.title}</h2><span class="chip amber">REVIEW</span></div><span class="eyebrow">${alert.area}</span><p>${alert.evidence}</p><ol>${alert.steps.map(step => `<li>${step}</li>`).join('')}</ol><form class="action-form" data-id="${alert.id}"><div class="form-grid"><label>Action taken<textarea name="note" required maxlength="2000" placeholder="Record your follow-up"></textarea></label><label>Reassessment time<input name="due" type="datetime-local" required></label></div><button class="button" type="submit" style="margin-top:16px">Record action & schedule follow-up</button></form>${history.length ? `<div class="action-history"><h3>Recorded follow-ups</h3>${history.map(action => `<p>${escape(action.note)}<br><span class="muted">Reassess ${new Date(action.due).toLocaleString()} · ${action.completed ? 'Completed' : new Date(action.due) < new Date() ? 'Due now' : 'Scheduled'}</span> ${action.completed ? '' : `<button class="text-link" data-complete="${action.id}">Mark reassessed</button>`}</p>`).join('')}</div>` : ''}</section>`;
  }).join('') + (!alerts.length ? '<section class="card"><h2>No active rule alerts</h2><p>Continue regular check-ins.</p></section>' : '') + `<section class="card"><h2>Outstanding reassessments</h2>${state.actions.filter(action => !action.completed).map(action => `<div class="action-history"><h3>${action.alertId === 'heart-rate' ? 'Resting heart rate' : 'Sleep & recovery'}</h3><p>${escape(action.note)}</p><p>${new Date(action.due) < new Date() ? 'Due now' : 'Scheduled'} · ${new Date(action.due).toLocaleString()}</p><button class="text-link" data-complete="${action.id}">Mark reassessed</button></div>`).join('') || '<p>No outstanding reassessments.</p>'}</section>`;
}
function summary() {
  return heading('Health summary', 'Review your records and prepare a crew medical handoff.', '<button class="button primary" id="export">↓ Export summary</button>') + `<section class="card"><div class="card-head"><h2>Measurement history</h2><span class="chip">${state.readings.length} RECORDS</span></div><p>Sample records and manual check-ins are labeled by source. The export includes all measurements, symptoms, alerts, and follow-ups.</p><div class="table-wrap"><table><thead><tr><th>Recorded</th><th>Heart rate</th><th>Sleep</th><th>Fatigue</th><th>Source</th></tr></thead><tbody>${state.readings.slice().reverse().map(item => `<tr><td>${escape(new Date(item.date).toLocaleString())}</td><td>${item.heartRate} bpm</td><td>${item.sleep} hrs</td><td>${item.fatigue}/10</td><td>${escape(item.source)}</td></tr>`).join('')}</tbody></table></div><p class="notice">Export downloads a JSON file for manual handoff. Device-local records can be accessed by anyone with access to this browser profile.</p></section>`;
}
function render() {
  const view = location.hash.slice(1) || 'overview';
  const titles = { overview: 'Overview', trends: 'Health trends', checkin: 'Daily check-in', alerts: 'Alerts & actions', summary: 'Health summary' };
  document.querySelector('#breadcrumb').textContent = titles[view] || 'Overview';
  document.querySelectorAll('nav a').forEach(link => { link.classList.toggle('active', link.dataset.view === view); if (link.dataset.view === view) link.setAttribute('aria-current', 'page'); else link.removeAttribute('aria-current'); });
  document.querySelector('#alert-count').textContent = evaluate(state.readings).length;
  const pages = { overview, checkin, alerts: alertsView, summary, trends: () => heading('Health trends', 'Track changes against your illustrative personal baseline.') + `<div class="columns">${chart()}${chart('sleep', 'Sleep duration', 'hrs')}</div><div class="lower">${chart('fatigue', 'Reported fatigue', '/10')}</div>` };
  main.innerHTML = (pages[view] || overview)();
  const connection = document.querySelector('#connection');
  connection.textContent = storageAvailable ? (navigator.onLine ? '● Local storage active' : '● Offline · local storage active') : 'Storage unavailable';
}
main.addEventListener('submit', event => {
  event.preventDefault();
  const data = new FormData(event.target);
  if (event.target.id === 'checkin-form') {
    const record = { id: crypto.randomUUID(), date: new Date().toISOString(), heartRate: Number(data.get('heartRate')), sleep: Number(data.get('sleep')), fatigue: Number(data.get('fatigue')), stress: Number(data.get('stress')), mood: data.get('mood'), exercise: data.get('exercise') === 'true', symptoms: data.get('symptoms').trim(), source: 'Manual check-in', sample: false };
    state.readings.push(record);
    state.checkins.push(record);
    const saved = save();
    location.hash = 'overview';
    if (saved) toast('Check-in saved on this device.');
  } else if (event.target.classList.contains('action-form')) {
    const due = new Date(data.get('due'));
    if (due <= new Date() || Number.isNaN(due.getTime())) { toast('Choose a future reassessment time.'); return; }
    const note = data.get('note').trim();
    if (!note) { toast('Record an action before scheduling a follow-up.'); return; }
    state.actions.push({ id: crypto.randomUUID(), alertId: event.target.dataset.id, note, due: due.toISOString(), date: new Date().toISOString(), completed: false });
    const saved = save();
    render();
    if (saved) toast('Action saved. Follow-up scheduled in this app.');
  }
});
main.addEventListener('click', event => {
  const rangeButton = event.target.closest('[data-range]');
  if (rangeButton) { range = Number(rangeButton.dataset.range); render(); }
  const completeButton = event.target.closest('[data-complete]');
  if (completeButton) {
    const action = state.actions.find(item => item.id === completeButton.dataset.complete);
    action.completed = true;
    action.completedAt = new Date().toISOString();
    save(); render();
  }
  if (event.target.closest('#export')) {
    const report = { application: 'Orbit Health prototype', exportedAt: new Date().toISOString(), profile: 'Alex Chen · Demo profile', baseline, activeAlerts: evaluate(state.readings), ...state };
    const url = URL.createObjectURL(new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' }));
    const link = document.createElement('a');
    link.href = url; link.download = `orbit-health-${new Date().toISOString().slice(0, 10)}.json`; link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    toast('Health summary exported.');
  }
});
window.addEventListener('hashchange', () => { render(); window.scrollTo(0, 0); });
window.addEventListener('online', render);
window.addEventListener('offline', render);
document.querySelector('#clock').textContent = new Date().toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
save(); render();
if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => toast('Offline caching is unavailable in this browser.'));
