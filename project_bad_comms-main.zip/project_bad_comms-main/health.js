export const baseline = { heartRate: 62, sleep: 8, fatigue: 2 };
export function evaluate(readings) {
  if (!readings.length) return [];
  const latest = readings.at(-1);
  const alerts = [];
  const recent = readings.slice(-3);
  if (recent.length === 3 && recent.every(item => item.heartRate >= baseline.heartRate + 10)) {
    alerts.push({ id: 'heart-rate', title: 'Resting heart rate is elevated', area: 'Cardiovascular', evidence: `Last 3 readings are at least 10 bpm above your ${baseline.heartRate} bpm sample baseline. Latest reading: ${latest.heartRate} bpm.`, steps: ['Review the measurement source and conditions.', 'Record a repeat measurement and any symptoms.', 'Review the findings with the crew medical officer.'] });
  }
  if (latest.sleep < 6 || latest.fatigue >= 7) {
    alerts.push({ id: 'recovery', title: 'Recovery needs a check-in', area: 'Sleep & recovery', evidence: `Latest sleep: ${latest.sleep} hours. Fatigue: ${latest.fatigue}/10. Demo rule triggers below 6 hours of sleep or at fatigue 7 and above.`, steps: ['Complete a sleep and symptom check-in.', 'Record workload and recent sleep interruptions.', 'Review persistent changes with the crew medical officer.'] });
  }
  return alerts;
}
