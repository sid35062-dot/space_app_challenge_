# Orbit Health

Local astronaut health monitoring prototype. Requires Node.js 20 or later.

```sh
npm start
```

Open http://localhost:3000. Run `npm run check` for JavaScript syntax checks.

Includes a dashboard, baseline trend charts, daily check-ins, illustrative rule alerts, action recording, reassessment scheduling, and JSON export. Initial records use simulated data. New entries are saved in browser localStorage. A service worker caches the application after its first successful load for offline use. Fonts have system fallbacks.

This prototype uses a fixed demo profile and sample baselines. Alert rules and guidance require clinical validation. Authentication, encrypted medical storage, sensor integrations, automatic transmission, and background notifications are pending. Follow-up status appears when the app is open. Use sample data during development.
